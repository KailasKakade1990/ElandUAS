package com.eland.uas.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eland.uas.entity.AssignSystemResource;
import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.Systems;
import com.eland.uas.entity.SystemsResource;
import com.eland.uas.entity.User;
import com.eland.uas.entity.UserRequest;
import com.eland.uas.entity.UserSystemsRole;
import com.eland.uas.repository.ResourceRepository;
import com.eland.uas.repository.RoleRepository;
import com.eland.uas.repository.SystemsResourceRepository;
import com.eland.uas.repository.SystemsRespository;
import com.eland.uas.repository.SystemsRoleRepository;
import com.eland.uas.repository.UserRepository;
import com.eland.uas.repository.UserSystemsRoleRepository;

@RestController
@RequestMapping("/uas")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminController {
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private ResourceRepository resourceRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private SystemsResourceRepository systemsResourceRepository;
	@Autowired
	private SystemsRespository systemsRepository;
	@Autowired
	private SystemsRoleRepository systemsRoleRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserSystemsRoleRepository userSystemsRoleRepository;

	/**********************************************************/
	// User API

	@PostMapping("/user")
	public String addUser(@RequestBody User user) {

		UserSystemsRole userSystemRole = new UserSystemsRole();
		String[] systemIds = user.getSystem_id();
		System.out.println("SysId:" + systemIds);
		String[] roleIds = user.getRole_id();
		User user1 = userRepository.save(user);
		System.out.println("User1:"+user1);
		userSystemRole.setUser(user1);
		for (String sysId : systemIds) {
			Systems system = systemsRepository.getOne(Long.parseLong(sysId));
			userSystemRole.setSystem(system);
			for (String roleId : roleIds) {
				Role role = roleRepository.getOne(Long.parseLong(roleId));
				userSystemRole.setRole(role);
				userSystemsRoleRepository.save(userSystemRole);
			}
		}
		return "User Saved Successfully!";
	}

	// List all Users from database;
	@GetMapping("/user")
	public List<UserSystemsRole> getUserList() {
		logger.debug("Get All UserLists");
		//return userRepository.findAll();
		return userSystemsRoleRepository.findAll();
	}

	// Return one Users from database;
	@GetMapping("user/{userId}")
	public Optional<User> getById(@PathVariable Long userId) {

		return userRepository.findById(userId);
	}

	// delete Single user by id of the Users from database;
	@DeleteMapping("user/{userId}")
	public boolean deleteUser(@PathVariable Long userId) {
		userRepository.deleteById(userId);
		return true;
	}

	// Update user Single user by id of the Users from database;
	@PutMapping("user/{userId}")
	public User updateUser(User user) {

		return userRepository.save(user);
	}

	/**********************************************************/

	// System API

	@PostMapping("/system")
	public String addSystem(@RequestBody Systems systemResource) {

		// Role role = null;
		//Systems system = null;
		// Resource resource = null;
		//system = systemResource.getSystem();
		// resource = systemResource.getResource();

		systemsRepository.save(systemResource);

		return "System Saved Successfully!";
	}

	// List all Users from database;
	@GetMapping("/system")
	public List<Systems> getSytemList() {
		logger.debug("Get All system");
		System.out.println("Hitting ");
		return systemsRepository.findAll();
	}

	// Return one Users from database;
	@GetMapping("system/{systemId}")
	public Optional<Systems> getSystemById(@PathVariable Long systemId) {
		logger.info("System Saved Successfully" + systemId);
		return systemsRepository.findById(systemId);
	}

	// delete Single user by id of the Users from database;
	@DeleteMapping("system/{systemId}")
	public boolean deleteSystem(@PathVariable Long systemId) {
		logger.info("System Saved Successfully" + systemId);
		userRepository.deleteById(systemId);
		return true;
	}

	// Update system from database;
	@PutMapping("system/{systemId}")
	public Systems update(Systems system) {

		return systemsRepository.save(system);
	}

	/**********************************************************/
	// Resource API
	@PostMapping("/resource")
	public String addResource(@RequestBody Resource resource) {
		resourceRepository.save(resource);
		logger.info("Resource Saved Successfully");
		return "Resource Saved Successfully!";

	}

	// List all Users from database;
	@GetMapping("/resource")
	public List<Resource> getResourceList() {
		logger.debug("Get All resources");
		System.out.println("Resource List:"+ resourceRepository.findAll());
		return resourceRepository.findAll();
	}

	// Return one resource from database;
	@GetMapping("resource/{resourceId}")
	public Optional<Resource> getResourceById(@PathVariable Long resourceId) {
		logger.info("Get one Resource by id" + resourceId);
		return resourceRepository.findById(resourceId);
	}

	// delete Single resource by id of the Users from database;
	@DeleteMapping("resource/{resourceId}")
	public boolean deleterResource(@PathVariable Long resourecId) {
		logger.info("Resource deleted Successfully!" + resourecId);
		userRepository.deleteById(resourecId);
		return true;
	}

	// Update user Single user by id of the Users from database;
	@PutMapping("resource/{resourceId}")
	public Resource update(Resource resource) {
		logger.info("Resource Saved Successfully!" + resource);
		return resourceRepository.save(resource);
	}

	/**********************************************************/
	// Add Role API

	// Add Role
	@PostMapping("/role")
	public String addRole(@RequestBody Role role) {
		roleRepository.save(role);
		logger.info("Role Saved Successfully!" + role);
		return "Role Saved Successfully";
	}

	// List all Users from database;
	@GetMapping("/role")
	public List<Role> getRoleList() {
		logger.debug("Get All Roles" + roleRepository.findAll());
		return roleRepository.findAll();
	}
	
	@GetMapping("/getAssignedRole")
	public List<UserSystemsRole> getAssignedRoleList() {
		logger.debug("Get All Roles" + userSystemsRoleRepository.findAll());
		return userSystemsRoleRepository.findAll();
	}

	// Return one role database by id;
	@GetMapping("role/{roleId}")
	public Optional<Role> roleFindById(@PathVariable Long roleId) {
		logger.debug("FindRoleBy ID Roles" + roleId);
		return roleRepository.findById(roleId);
	}

	// delete role from database
	@DeleteMapping("role/{roleId}")
	public boolean roleDeleteById(@PathVariable Long roleId) {
		userRepository.deleteById(roleId);
		logger.debug("Role Deleted Successfully!" + roleId);
		return true;
	}

	// Update by id
	@PutMapping("role/{roleId}")
	public Role update(Role role) {
		logger.debug("Role Updated Successfully!" + role);
		return roleRepository.save(role);
	}

	@PostMapping("/systemResources")
	public String addSystemResources(@RequestBody AssignSystemResource systemresource) {

		SystemsResource sysResource = new SystemsResource();
		String[] systemIds = systemresource.getSystemId();
		String[] resourceIds = systemresource.getResourceId();
		for (String sysId : systemIds) {
			Systems system = systemsRepository.getOne(Long.parseLong(sysId));
			System.out.println("SID:"+system.getSystemId());
			sysResource.setSystem(system);
			for (String resourceId : resourceIds) {
				Resource resource = resourceRepository.getOne(Long.parseLong(resourceId));
				System.out.println("RID:"+resource.getResourceId());
				sysResource.setResource(resource);
				sysResource.setIsUse(systemresource.getIsUse());
				systemsResourceRepository.save(sysResource);
			}
		}
		logger.info("Resources Assigned Successfully!" + sysResource);
		return "Role Saved Successfully";
	}
	@GetMapping("/systemResources")
	public List<SystemsResource> viewSystemResources() {
		System.out.println("System Resources:"+systemsResourceRepository.findAll());
		return systemsResourceRepository.findAll();
	}

}
