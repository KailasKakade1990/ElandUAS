package com.eland.uas.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "system_role")
public class SystemsRole {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "system_role_id")
	private Long systemRoleId;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "system_id")
	private Systems system;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "role_id")
	private Role role;
//not in use
	/*
	 * @ManyToOne(cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "user_id") private User user;
	 */

	@Column(name = "is_use")
	private Long is_use;

	@Column(name = "user_count")
	private Long userCount;

	@Column(name = "role_count")
	private Long roleCount;

	public Long getSystemRoleId() {
		return systemRoleId;
	}

	public void setSystemRoleId(Long systemRoleId) {
		this.systemRoleId = systemRoleId;
	}

	public Systems getSystem() {
		return system;
	}

	public void setSystem(Systems system) {
		this.system = system;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Long getIs_use() {
		return is_use;
	}

	public void setIs_use(Long is_use) {
		this.is_use = is_use;
	}

	public Long getUserCount() {
		return userCount;
	}

	public void setUserCount(Long userCount) {
		this.userCount = userCount;
	}

	public Long getRoleCount() {
		return roleCount;
	}

	public void setRoleCount(Long roleCount) {
		this.roleCount = roleCount;
	}

}
