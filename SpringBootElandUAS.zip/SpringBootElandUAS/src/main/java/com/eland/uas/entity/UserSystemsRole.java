package com.eland.uas.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_system_role")
public class UserSystemsRole implements Serializable {

	private static final long serialVersionUID = -7230396126349228044L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_system_role_id")
	private Integer userSystemRoleId;
	@ManyToOne
	@JoinColumn(name = "user_id", nullable = false)
	private User user;
	@ManyToOne
	@JoinColumn(name = "system_id", nullable = false)
	private Systems system;
	@ManyToOne
	@JoinColumn(name = "role_id", nullable = false)
	private Role role;
	@Column(name = "is_use")
	private Integer isUse;
	public Integer getUserSystemRoleId() {
		return userSystemRoleId;
	}

	public void setUserSystemRoleId(Integer userSystemRoleId) {
		this.userSystemRoleId = userSystemRoleId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Systems getSystem() {
		return system;
	}

	public void setSystem(Systems system) {
		this.system = system;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Integer getIsUse() {
		return isUse;
	}

	public void setIsUse(Integer isUse) {
		this.isUse = isUse;
	}
}
