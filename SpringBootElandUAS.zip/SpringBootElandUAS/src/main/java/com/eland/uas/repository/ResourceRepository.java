package com.eland.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.Resource;

public interface ResourceRepository extends JpaRepository<Resource, Long> {

}
